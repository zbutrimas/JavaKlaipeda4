package fundamentals_testing;

public class Calculator {

    public int add(int firstNum, int secondNum) {
        return firstNum + secondNum;
    }

    public int divide(int firstNum, int secondNum) {
        return firstNum / secondNum;
    }

    public int subtract(int firstNum, int secondNum) {
        return firstNum - secondNum;
    }

    public int multiply(int firstNum, int secondNum) {
        return firstNum * secondNum;
    }
}
