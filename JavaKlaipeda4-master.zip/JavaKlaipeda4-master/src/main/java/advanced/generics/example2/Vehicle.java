package advanced.generics.example2;

public abstract class Vehicle {

    public abstract void repair();
}
