package advanced.generics.example2;

public class Boat {
}
