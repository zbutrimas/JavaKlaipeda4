package advanced.generics.example2;

public class Motorcycle extends Vehicle {

    @Override
    public void repair() {
        System.out.println("Motorcycle is repaired!");
    }
}
