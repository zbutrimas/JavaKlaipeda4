package advanced.generics.example2;

public class Car extends Vehicle {

    @Override
    public void repair() {
        System.out.println("Car ir repaired!");
    }
}
