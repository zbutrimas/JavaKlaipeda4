package advanced.generics.example1;

public class Car {

    private int engine;

    public Car(int engine) {
        this.engine = engine;
    }
}
