package advanced.composition;

public class Bed {

    private double length;
    private double width;

    public Bed(double length, double width) {
        this.length = length;
        this.width = width;
    }
}
