package advanced.composition;

public class Tv {

    private String resolution;

    public Tv(String resolution) {
        this.resolution = resolution;
    }
}
