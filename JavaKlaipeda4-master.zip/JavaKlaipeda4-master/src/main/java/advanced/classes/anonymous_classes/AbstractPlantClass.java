package advanced.classes.anonymous_classes;

public abstract class AbstractPlantClass {

    public abstract String getPlantName();
}
