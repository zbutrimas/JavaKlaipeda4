package advanced.enumerators;

public enum Coffee {
    LATTE,
    ESPRESSO,
    AMERICANO
}
