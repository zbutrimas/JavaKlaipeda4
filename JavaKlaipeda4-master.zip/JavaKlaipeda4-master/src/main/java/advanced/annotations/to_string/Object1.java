package advanced.annotations.to_string;

public class Object1 {
}
