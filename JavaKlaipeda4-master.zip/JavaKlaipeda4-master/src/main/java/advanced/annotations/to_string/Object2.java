package advanced.annotations.to_string;

public class Object2 {

    @Override
    public String toString() {
        return Object2.class.getSimpleName();
    }
}
