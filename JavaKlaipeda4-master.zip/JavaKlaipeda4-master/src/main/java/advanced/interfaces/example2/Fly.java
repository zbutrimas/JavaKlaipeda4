package advanced.interfaces.example2;

public interface Fly {

    int maxSpeed();

    boolean canFly(String condition);
}
