package advanced.interfaces.example2;

public abstract class AirTransport {

    protected int speed;

    public AirTransport(int speed) {
        this.speed = speed;
    }
}
